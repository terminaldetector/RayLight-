-- ═══════════════════════════════════════════════════════════
-- weapon_d6_concussion.lua — КС-РАКЕТА (тяжёлая ударная ракета)
--
--   Cat B: LIMITED AMMO. Без расхода энергии.
--   Медленная (1600 u/s), большой взрыв 280u. Тяжёлая отдача 200.
--   Разрушение комнат. Добивание тяжёлых целей.
--   Отличие от Homing/Smart: прямолётная, наибольший урон/взрыв.
-- ═══════════════════════════════════════════════════════════
AddCSLuaFile()

SWEP.PrintName      = "КС-РАКЕТА"
SWEP.Author         = "Half-Life: Abaddon"
SWEP.Category       = "Descent"
SWEP.Slot           = 4
SWEP.SlotPos        = 3
SWEP.Spawnable      = true
SWEP.AdminSpawnable = true
SWEP.Base           = "weapon_base"
SWEP.HoldType       = "physgun"
SWEP.ViewModel      = "models/weapons/v_physics.mdl"
SWEP.WorldModel     = "models/weapons/w_physics.mdl"
SWEP.UseHands       = false
SWEP.DrawAmmo       = false
SWEP.DrawCrosshair  = false
SWEP.Primary.ClipSize      = -1
SWEP.Primary.DefaultClip   = 0
SWEP.Primary.Automatic     = false
SWEP.Primary.Ammo          = "d6_concussion"
SWEP.Secondary.ClipSize    = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic   = false
SWEP.Secondary.Ammo        = "none"

local MDL_MISSILE = "models/weapons/w_missile.mdl"
if SERVER then
    util.PrecacheModel(MDL_MISSILE)
    util.PrecacheSound("weapons/rpg/rocketfire1.wav")
    util.PrecacheSound("weapons/rpg/rocket_explode.wav")
end

local AMMO_TYPE  = "d6_concussion"
local MAX_AMMO   = 6
local FIRE_RATE  = 2.0
local PROJ_SPEED = 1600
local DIRECT_DMG = 120
local SPLASH_DMG = 90
local SPLASH_RAD = 280
local RECOIL     = 200
local MUZZLE     = { fwd = 32, rgt = 0, up = -10 }

function SWEP:Initialize()
    self:SetWeaponHoldType(self.HoldType)
end

function SWEP:Deploy()  return true end
function SWEP:Holster() return true end

function SWEP:PrimaryAttack()
    if not SERVER then return end
    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    if owner:GetAmmoCount(AMMO_TYPE) <= 0 then
        owner:EmitSound("buttons/button10.wav", 65, 100); return
    end
    owner:RemoveAmmo(1, AMMO_TYPE)
    self:SetNextPrimaryFire(CurTime() + FIRE_RATE)

    local sa  = D6_Wep.ShootAng(owner)
    local dir = sa:Forward()
    local src = D6_Wep.MuzzleFor(owner, self:GetClass(), 1, MUZZLE)

    D6_Wep.FireProjectile({
        art = "shot_shell", muzzleFX = true,
        weapon = self,
        converge = true,
        owner      = owner,
        pos        = src,
        dir        = dir,
        speed      = PROJ_SPEED,
        model      = MDL_MISSILE,
        scale      = 1.6,
        color      = Color(255, 100, 20, 255),
        dmgClass   = "explosive",
        physRadius = 8,
        mass       = 8,
        recoil     = RECOIL,
        life       = 8,
        trails     = {
            { col = Color(255, 100, 20),  sw = 60, ew = 8, life = 0.8 },
            { col = Color(255, 220, 160), sw = 20, ew = 2, life = 0.5 },
        },
        onHit = function(b, hitEnt, hitPos, hitNormal)
            if not hitPos then return end
            local pos = hitPos

            if D6_Wep.Damageable(hitEnt) then
                D6_Wep.DirectDamage(owner, b, hitEnt, DIRECT_DMG, DMG_BLAST,
                    (hitNormal or -dir) * 7000)
            end
            D6_Wep.SplashDamage(owner, b, pos, 0, SPLASH_DMG, SPLASH_RAD, DMG_BLAST, 6000, hitEnt)

            local ef = EffectData()
            ef:SetOrigin(pos); ef:SetScale(3); ef:SetMagnitude(SPLASH_RAD)
            util.Effect("HelicopterMegaBomb", ef)
            local ef2 = EffectData()
            ef2:SetOrigin(pos); ef2:SetScale(3)
            util.Effect("cball_explode", ef2)
            sound.Play("weapons/rpg/rocket_explode.wav", pos, 100, 80)
        end,
    })

    local ef = EffectData(); ef:SetOrigin(src); ef:SetNormal(dir)
    util.Effect("RPGShot", ef)
    owner:EmitSound("weapons/rpg/rocketfire1.wav", 90, 85)
end

function SWEP:SecondaryAttack()
    self:SetNextSecondaryFire(CurTime() + 0.5)
end

if CLIENT then
    function SWEP:DrawHUD()
        D6_Wep.DrawAmmoHUD(self:GetOwner(), "КС-РАКЕТА", AMMO_TYPE, MAX_AMMO,
            Color(255, 100, 20))
    end
end

function SWEP:DrawWorldModel()
    if D6_Art then D6_Art.DrawWorldWeapon(self) else self:DrawModel() end
end
function SWEP:DrawWorldModelTranslucent() end

print("[D6] weapon_d6_concussion.lua loaded")
